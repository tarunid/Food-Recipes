 const express = require("express");
 const fileUpload = require("express-fileupload");
 const path = require("path");

 const filespayloadexist = require('./middleware/filespayloadexist');
 const filesExtlimiter = require('./middleware/filesExtlimiter');
 const filesizelimiter = require('./middleware/filesizelimiter');

 const PORT = process.env.PORT || 5000;

 const app = express();
 app.use("./css",express.static("css"))

app.get("/", (req,res) => {
    res.sendFile(path.join(__dirname,"index.html"));
});

app.post('/upload',
    fileUpload({ createParentPath: true}),
    filespayloadexist,
    filesExtlimiter(['.png','.jpg','.jpeg']),
    filesizelimiter,
    (req, res) => {
       const files = req.files 
       console.log(files)

       Object.keys(files).forEach(key => {
        const filepath = path.join(__dirname,'files',files[key].name)
        files[key].mv(filepath,(err) => {
            if(err) return res.status(500).json({ status :"error", message : err})
        })
       })

       return res.json({ status: 'success' , message: Object.key(files).toString()});
    }
);

 app.listen(PORT, ()=> console.log(`Server running on port ${PORT}`));