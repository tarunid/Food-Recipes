const mysql = require("mysql");
const express = require("express");


const app = express();
app.use("./css",express.static("css"))

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "stevehami2003",
    database: "nodejs"
});

connection.connect(function(error){
    if(error) {
        throw error;
    }
    else {
        console.log("connected to the database successfully!");
    }
})

app.get("/", function(req,res){
    res.sendFile(__dirname+"/index.html");
})

app.use(express.urlencoded({
    extended: true
}));

app.use(express.json())

app.post("/",function(req,res){
    var username = req.body.username;
    var password = req.body.password;
    connection.query("select*from loginuser where user-name =? and user_pass=?",[username,password],function(error,results,fields){
        if(results.length > 0){
            res.redirect("logged in");
        }else{
            res.redirect("/");
        }
        res.end();
    })
})

app.listen(3000);
